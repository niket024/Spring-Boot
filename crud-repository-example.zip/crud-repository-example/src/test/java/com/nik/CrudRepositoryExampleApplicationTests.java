package com.nik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudRepositoryExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

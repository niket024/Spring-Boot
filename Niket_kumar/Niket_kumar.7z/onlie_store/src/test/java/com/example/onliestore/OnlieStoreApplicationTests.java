package com.example.onliestore;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;

import com.nik.OnlineStoreApplication;
import com.nik.controller.ProductController;

@SpringBootTest(classes = OnlineStoreApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT)

class OnlieStoreApplicationTests {
	@LocalServerPort
	private int port;
	@InjectMocks
	ProductController productController;

	@Test
	void testTotalCount() {
		assertTrue(productController.getAllProducts().getBody().size() == 1);
	}

	@Test
	void testGroupByBrand() {
		assertTrue(productController.getAllProductsByBrand("aaa").getBody().size() == 1);
	}

	@Test
	void testGroupByPrice() {
		assertTrue(productController.getAllProductsByBrand("1000").getBody().size() == 1);
	}

	@Test
	void testGroupByColor() {
		assertTrue(productController.getAllProductsByBrand("red").getBody().size() == 1);
	}

	@Test
	void testGroupBySize() {
		assertTrue(productController.getAllProductsByBrand("large").getBody().size() == 1);
	}

}

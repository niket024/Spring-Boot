package com.nik.service;

import java.util.List;

import com.nik.modal.Product;

public interface ProductService {

	void save(Product product);

	List<Product> findAll();

	List<Product> getAllProductsByBrand(String brand);

	List<Product> getAllProductsByPrice(String price);

	List<Product> getAllProductsByColor(String color);

	List<Product> getAllProductsBySize(String size);
}

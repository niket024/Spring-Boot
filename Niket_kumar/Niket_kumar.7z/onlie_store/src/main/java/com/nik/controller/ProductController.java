package com.nik.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nik.modal.Product;
import com.nik.service.ProductService;

@RestController
@RequestMapping("/online")

public class ProductController {
	@Autowired
	ProductService productService;

	public void createSeedData() {
		Product product = new Product();
		product.setBrand("aaa");
		product.setColor("red");
		product.setPrice("1000");
		product.setQuantity(12);
		product.setSize("large");
		product.setSKU("yes");
		productService.save(product);
	}

	@PostMapping
	public ResponseEntity<Object> create(@RequestBody Product prod) {
		productService.save(prod);
		return new ResponseEntity<Object>(HttpStatus.CREATED);
	}

	@GetMapping("allproducts")
	public ResponseEntity<List<Product>> getAllProducts() {
		createSeedData();
		List<Product> products = productService.findAll();
		return new ResponseEntity(products, HttpStatus.OK);
	}

	@GetMapping("/groupBybrand/{brand}")
	public ResponseEntity<List<Product>> getAllProductsByBrand(@PathVariable("brand") String brand) {
		createSeedData();
		List<Product> products = productService.getAllProductsByBrand(brand);
		return new ResponseEntity(products, HttpStatus.OK);
	}

	@GetMapping("/groupByPrice/{price}")
	public ResponseEntity<List<Product>> getAllProductsByPrice(@PathVariable("price") String price) {
		createSeedData();
		List<Product> products = productService.getAllProductsByPrice(price);
		return new ResponseEntity(products, HttpStatus.OK);
	}

	@GetMapping("/groupByColor/{color}")
	public ResponseEntity<List<Product>> getAllProductsByColor(@PathVariable("price") String color) {
		createSeedData();
		List<Product> products = productService.getAllProductsByColor(color);
		return new ResponseEntity(products, HttpStatus.OK);
	}

	@GetMapping("/groupBySize/{size}")
	public ResponseEntity<List<Product>> getAllProductsBySize(@PathVariable("price") String size) {
		createSeedData();
		List<Product> products = productService.getAllProductsBySize(size);
		return new ResponseEntity(products, HttpStatus.OK);
	}
}

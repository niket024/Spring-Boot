package com.nik.service;

import java.util.List;

import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nik.modal.Product;
import com.nik.repository.ProductRepo;

@Service("onlineService")
public class ProductServiceImpl implements ProductService {
	@Autowired(required = true)
	ProductRepo productRepo;

	public void setProductRepo(ProductRepo productRepo) {
		this.productRepo = productRepo;
	}

	public ProductRepo getProductRepo() {
		return productRepo;
	}

	@Override
	public void save(Product product) {
		productRepo.save(product);
	}

	@Override
	public List<Product> findAll() {
		return productRepo.findAll();

	}

	@Override
	public List<Product> getAllProductsByBrand(String brand) {
		return productRepo.getAllProductsByBrand(brand);
	}

	@Override
	public List<Product> getAllProductsByPrice(String price) {
		return productRepo.getAllProductsByPrice(price);
	}

	@Override
	public List<Product> getAllProductsByColor(String color) {
		return productRepo.getAllProductsByColor(color);
	}

	@Override
	public List<Product> getAllProductsBySize(String size) {
		return productRepo.getAllProductsBySize(size);
	}
}
